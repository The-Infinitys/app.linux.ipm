# Infinity Package Manager's Default Package

Descriptions of Package

